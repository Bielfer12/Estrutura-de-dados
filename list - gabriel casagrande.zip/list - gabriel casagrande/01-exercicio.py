class VetorOrdenado:
    def __init__(self, capacidade):
        self.__ultima_posicao = -1
        self.__capacidade = capacidade
        self.__valores = [''] * capacidade

    def inserir(self, valor):
        if self.__ultima_posicao == self.__capacidade - 1:
            print('Mensagem de Vetor Cheio')
            return
        
        posição = 0
        for i in range(self.__ultima_posicao + 1):
            posição = i
            if self.__valores[i] > valor:
                break
            if i == self.__ultima_posicao:
                posição = i + 1

        x = self.__ultima_posicao 
        while x >= posição:
            self.__valores[x + 1] = self.__valores[x]
            x -= 1
        self.__valores[posição] = valor
        self.__ultima_posicao += 1

    def imprimir(self):
        if self.__ultima_posicao == -1:
            print("Vetor vazio")
        else:
            for i in range(self.__ultima_posicao + 1):
                print(f"{i} - {self.__valores[i]}")

    def pesquisa_linear(self, valor):
        for i in range(self.__ultima_posicao + 1):
            if self.__valores[i] == valor:
                return i
        return -1

    def pesquisa_binaria(self, valor):
        limite_inferior = 0
        limite_superior = self.__ultima_posicao

        while limite_inferior <= limite_superior:
            posicao_atual = (limite_inferior + limite_superior) // 2
            
            if self.__valores[posicao_atual] == valor:
                return posicao_atual 
            
            elif self.__valores[posicao_atual] < valor:
                limite_inferior = posicao_atual + 1
            else:
                limite_superior = posicao_atual - 1
        
        return -1

    def excluir(self, valor, pesquisar):
        posição = pesquisar(valor)
        if posição == -1:
            return -1
        
        for i in range(posição, self.__ultima_posicao):
            self.__valores[i] = self.__valores[i + 1]
        
        self.__ultima_posicao -= 1
        self.__valores[self.__ultima_posicao + 1] = ''  # Clear the last element
        return posição

def main():
    vetor_ordenado = VetorOrdenado(7)
    vetor_ordenado.inserir('A')
    vetor_ordenado.inserir('B')
    vetor_ordenado.inserir('E')
    vetor_ordenado.inserir('G')
    vetor_ordenado.inserir('I')
    vetor_ordenado.inserir('L')
    vetor_ordenado.inserir('R')

    # B
    print("Conteúdo do vetor após inserções:")
    vetor_ordenado.imprimir()

    # C
    pesquisa01 = vetor_ordenado.pesquisa_binaria('G')
    pesquisa02 = vetor_ordenado.pesquisa_binaria('A')
    pesquisa03 = vetor_ordenado.pesquisa_binaria('B')
    
    print(f"'G' encontrado na posição: {pesquisa01}")
    print(f"'A' encontrado na posição: {pesquisa02}")
    print(f"'B' encontrado na posição: {pesquisa03}")

    print("Conteúdo do vetor após pesquisas:")
    vetor_ordenado.imprimir()

    print("Pesquisar por 'A':", vetor_ordenado.pesquisa_linear('A'))
    print("Pesquisar por 'G':", vetor_ordenado.pesquisa_linear('G'))
    print("Pesquisar por 'R':", vetor_ordenado.pesquisa_linear('R'))

    # D
    vetor_ordenado.excluir('A', vetor_ordenado.pesquisa_binaria)
    vetor_ordenado.excluir('G', vetor_ordenado.pesquisa_binaria)
    vetor_ordenado.excluir('R', vetor_ordenado.pesquisa_binaria)

    # E
    print("Conteúdo do vetor após exclusões:")
    vetor_ordenado.imprimir()

if __name__ == "__main__":
    main()

